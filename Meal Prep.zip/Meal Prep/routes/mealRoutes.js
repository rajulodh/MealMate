const express = require('express');
const router = express.Router();
const mealController = require('../controllers/mealController');

function isAuth(req, res, next) {
  if (!req.session.user) return res.redirect('/login');
  next();
}

router.get('/', isAuth, mealController.listMeals);
router.post('/create', isAuth, mealController.createOrUpdateMeal);
router.get('/edit/:id', isAuth, mealController.editMeal);
router.post('/delete/:id', isAuth, mealController.deleteMeal);

module.exports = router;
