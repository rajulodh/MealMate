const Meal = require('../models/Meal');

exports.listMeals = async (req, res) => {
  const meals = await Meal.find({ user: req.session.user.id });
  res.render('index', { meals, editingMeal: null, layout: 'layout' });
};

exports.createOrUpdateMeal = async (req, res) => {
  const { id, mealName, day, time, ingredients, calories, prepTime, mealType } = req.body;
  const image = req.body.image || '/images/default-meal.jpg';
  try {
    if (id) {
      await Meal.findOneAndUpdate({ _id: id, user: req.session.user.id }, {
        mealName, day, time, ingredients, calories, prepTime, mealType, image
      });
    } else {
      await Meal.create({
        mealName, day, time, ingredients, calories, prepTime, mealType, image, user: req.session.user.id
      });
    }
    res.redirect('/meals');
  } catch (err) {
    res.status(500).send('Failed to save meal.');
  }
};

exports.editMeal = async (req, res) => {
  const editingMeal = await Meal.findOne({ _id: req.params.id, user: req.session.user.id });
  const meals = await Meal.find({ user: req.session.user.id });
  res.render('index', { meals, editingMeal, layout: 'layout' });
};

exports.deleteMeal = async (req, res) => {
  await Meal.deleteOne({ _id: req.params.id, user: req.session.user.id });
  res.redirect('/meals');
};
