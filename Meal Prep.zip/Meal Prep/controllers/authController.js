const User = require('../models/User');
const bcrypt = require('bcryptjs');

exports.signupForm = (req, res) => {
  res.render('signup', { error: null, layout: 'layout' });
};

exports.signup = async (req, res) => {
  const { email, password } = req.body;
  try {
    const exists = await User.findOne({ email });
    if (exists) return res.render('signup', { error: 'Email already registered.', layout: 'layout' });
    const hashed = await bcrypt.hash(password, 10);
    const user = await User.create({ email, password: hashed });
    req.session.user = { id: user._id, email: user.email };
    res.redirect('/meals');
  } catch {
    res.render('signup', { error: 'Signup failed. Try again.', layout: 'layout' });
  }
};

exports.loginForm = (req, res) => {
  res.render('login', { error: null, layout: 'layout' });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.render('login', { error: 'Invalid credentials.', layout: 'layout' });
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.render('login', { error: 'Invalid credentials.', layout: 'layout' });
    req.session.user = { id: user._id, email: user.email };
    res.redirect('/meals');
  } catch {
    res.render('login', { error: 'Login failed. Try again.', layout: 'layout' });
  }
};

exports.logout = (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
};
