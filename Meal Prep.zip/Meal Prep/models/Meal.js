const mongoose = require('mongoose');

const mealSchema = new mongoose.Schema({
  mealName: String,
  day: String,
  time: String,
  ingredients: String,
  calories: Number,
  prepTime: Number,
  mealType: String,
  image: String,
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
});

module.exports = mongoose.model('Meal', mealSchema);
